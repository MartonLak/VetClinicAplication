create function lpad(text, integer) returns text
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function lpad(text, integer, text) is 'left-pad string to length';

alter function lpad(text, integer, text) owner to lakatosmarton;

