create function xpath(text, xml) returns xml[]
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function xpath(text, xml, text[]) is 'evaluate XPath expression';

alter function xpath(text, xml, text[]) owner to lakatosmarton;

